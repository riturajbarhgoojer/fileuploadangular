import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IAnotherParams } from '../interfaces/IAnotherParams'

@Injectable({
    providedIn: 'root',
})

export class PostHelper {
    private baseUrl = 'http://localhost:5041/api';

    constructor(private http: HttpClient) { }

    public POST(params: FormData) : Observable<HttpEvent<any>> {

        const req = new HttpRequest('POST', `${this.baseUrl}/FileUpload`, params, {
            responseType: 'json',
        });

        return this.http.request(req);
    }

}