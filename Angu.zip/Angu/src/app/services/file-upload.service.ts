import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

import {IAnotherParams} from '../interfaces/IAnotherParams';

import {PostHelper} from '../PostHelper/helper'

@Injectable({
  providedIn: 'root',
})
 

export class FileUploadService {
  private baseUrl = 'http://localhost:5041/api';

  constructor(private http: HttpClient) {}

  upload(file: File): Observable<any> {
      
    let anotherParams: IAnotherParams ;

    const formData: FormData = new FormData();

     
    formData.append('file', file);
    formData.append('id', "1");
    formData.append('name', "Raj");
    formData.append('email', "application@name.com");
    formData.append('fileContentType', "application/pdf");
    formData.append('fileName', "dummy.pdf");

     var req = new PostHelper(this.http).POST(formData);

    return req;
  }

  getFiles(): Observable<any> {
    return this.http.get(`${this.baseUrl}/files`);
  }
}