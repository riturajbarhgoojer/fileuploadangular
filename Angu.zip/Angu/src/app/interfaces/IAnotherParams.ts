export interface IAnotherParams 
{
    id:string, 
    name:string,  
    email:string,  
    fileContentType:string,  
    fileName:string,  

} 